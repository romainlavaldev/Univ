package com.soprasteria.panier.model.exceptions;

public class ArticleInexistantException extends Exception {
	public ArticleInexistantException( String message ) {
		super( message );
	}
}
