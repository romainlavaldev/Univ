package com.soprasteria.panier.model.exceptions;

public class TropDeReferencesException extends Exception {
	public TropDeReferencesException( String message ) {
		super( message );
	}
}