void initPile();
int pileVide();
void empiler(int);
void depiler(int *);
void sommetPile(int *);