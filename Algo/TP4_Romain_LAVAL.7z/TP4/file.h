

void initFile(void);
void ajouter(int);
void retirer(int *);
int fileVide(void);
