void initPile();
void empiler(int);
void depiler(int *);
void pileVide();